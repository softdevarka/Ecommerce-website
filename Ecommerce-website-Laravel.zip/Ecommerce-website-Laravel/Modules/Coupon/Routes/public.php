<?php

Route::post('cart/coupon', 'CartCouponController@store')->name('cart.coupon.store');
