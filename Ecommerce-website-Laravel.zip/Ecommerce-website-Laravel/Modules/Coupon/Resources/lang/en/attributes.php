<?php

return [
    'name' => 'Name',
    'code' => 'Code',
    'is_percent' => 'Discount Type',
    'value' => 'Value',
    'free_shipping' => 'Free Shipping',
    'start_date' => 'Start date',
    'end_date' => 'End date',
    'is_active' => 'Status',
    'minimum_spend' => 'Minimum Spend',
    'maximum_spend' => 'Maximum Spend',
    'products' => 'Products',
    'exclude_products' => 'Exclude Products',
    'categories' => 'Categories',
    'exclude_categories' => 'Exclude Categories',
    'usage_limit_per_coupon' => 'Usage Limit Per Coupon',
    'usage_limit_per_customer' => 'Usage Limit Per Customer',
];
