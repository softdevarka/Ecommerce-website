<?php

return [
    'rate' => 'Rate',
];
