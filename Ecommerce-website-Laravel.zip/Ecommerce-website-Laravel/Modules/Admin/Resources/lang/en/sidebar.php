<?php

return [
    'content' => 'Content',
    'sales' => 'Sales',
    'system' => 'System',
    'localization' => 'Localization',
    'appearance' => 'Appearance',
];
