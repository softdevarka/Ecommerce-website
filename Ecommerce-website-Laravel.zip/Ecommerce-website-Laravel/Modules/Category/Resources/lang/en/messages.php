<?php

return [
    'category_order_saved' => 'Category order has been saved.',
];
