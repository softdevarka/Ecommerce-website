<?php

return [
    'admin.media' => [
        'index' => 'media::permissions.index',
        'create' => 'media::permissions.create',
        'edit' => 'media::permissions.edit',
        'destroy' => 'media::permissions.destroy',
    ],
];
