<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Review\\Providers\\ReviewServiceProvider',
    1 => 'Modules\\Review\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Review\\Providers\\ReviewServiceProvider',
    1 => 'Modules\\Review\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);