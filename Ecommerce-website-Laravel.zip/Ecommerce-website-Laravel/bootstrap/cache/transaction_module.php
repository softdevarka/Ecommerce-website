<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Transaction\\Providers\\TransactionServiceProvider',
    1 => 'Modules\\Transaction\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Transaction\\Providers\\TransactionServiceProvider',
    1 => 'Modules\\Transaction\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);