<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Compare\\Providers\\CompareServiceProvider',
    1 => 'Modules\\Compare\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Compare\\Providers\\CompareServiceProvider',
    1 => 'Modules\\Compare\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);