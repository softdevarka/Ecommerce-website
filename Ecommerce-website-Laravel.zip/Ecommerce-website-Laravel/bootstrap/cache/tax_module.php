<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Tax\\Providers\\TaxServiceProvider',
    1 => 'Modules\\Tax\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Tax\\Providers\\TaxServiceProvider',
    1 => 'Modules\\Tax\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);