<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Support\\Providers\\RouteServiceProvider',
    1 => 'Modules\\Support\\Providers\\MySQLScoutServiceProvider',
    2 => 'Modules\\Support\\Providers\\EloquentMacroServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Support\\Providers\\RouteServiceProvider',
    1 => 'Modules\\Support\\Providers\\MySQLScoutServiceProvider',
    2 => 'Modules\\Support\\Providers\\EloquentMacroServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);