<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Media\\Providers\\MediaServiceProvider',
    1 => 'Modules\\Media\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Media\\Providers\\MediaServiceProvider',
    1 => 'Modules\\Media\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);