<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Category\\Providers\\CategoryServiceProvider',
    1 => 'Modules\\Category\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Category\\Providers\\CategoryServiceProvider',
    1 => 'Modules\\Category\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);